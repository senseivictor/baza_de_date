import pymysql

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "lab2",
    "cursorclass": pymysql.cursors.DictCursor
}
